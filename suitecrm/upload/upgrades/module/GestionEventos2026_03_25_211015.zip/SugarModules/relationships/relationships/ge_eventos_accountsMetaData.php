<?php
// created: 2026-03-25 21:10:15
$dictionary["ge_eventos_accounts"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'ge_eventos_accounts' => 
    array (
      'lhs_module' => 'GE_Eventos',
      'lhs_table' => 'ge_eventos',
      'lhs_key' => 'id',
      'rhs_module' => 'Accounts',
      'rhs_table' => 'accounts',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'ge_eventos_accounts_c',
      'join_key_lhs' => 'ge_eventos_accountsge_eventos_ida',
      'join_key_rhs' => 'ge_eventos_accountsaccounts_idb',
    ),
  ),
  'table' => 'ge_eventos_accounts_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'ge_eventos_accountsge_eventos_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'ge_eventos_accountsaccounts_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'ge_eventos_accountsspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'ge_eventos_accounts_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'ge_eventos_accountsge_eventos_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'ge_eventos_accounts_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'ge_eventos_accountsaccounts_idb',
      ),
    ),
  ),
);