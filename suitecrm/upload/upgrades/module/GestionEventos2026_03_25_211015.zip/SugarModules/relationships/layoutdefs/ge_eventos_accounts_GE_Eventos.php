<?php
 // created: 2026-03-25 21:10:15
$layout_defs["GE_Eventos"]["subpanel_setup"]['ge_eventos_accounts'] = array (
  'order' => 100,
  'module' => 'Accounts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_GE_EVENTOS_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'get_subpanel_data' => 'ge_eventos_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
