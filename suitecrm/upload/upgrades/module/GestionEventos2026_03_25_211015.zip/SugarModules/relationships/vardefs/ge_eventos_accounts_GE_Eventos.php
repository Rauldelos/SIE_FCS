<?php
// created: 2026-03-25 21:10:15
$dictionary["GE_Eventos"]["fields"]["ge_eventos_accounts"] = array (
  'name' => 'ge_eventos_accounts',
  'type' => 'link',
  'relationship' => 'ge_eventos_accounts',
  'source' => 'non-db',
  'module' => 'Accounts',
  'bean_name' => 'Account',
  'side' => 'right',
  'vname' => 'LBL_GE_EVENTOS_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
