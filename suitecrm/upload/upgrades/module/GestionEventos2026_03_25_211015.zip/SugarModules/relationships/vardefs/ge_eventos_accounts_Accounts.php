<?php
// created: 2026-03-25 21:10:15
$dictionary["Account"]["fields"]["ge_eventos_accounts"] = array (
  'name' => 'ge_eventos_accounts',
  'type' => 'link',
  'relationship' => 'ge_eventos_accounts',
  'source' => 'non-db',
  'module' => 'GE_Eventos',
  'bean_name' => 'GE_Eventos',
  'vname' => 'LBL_GE_EVENTOS_ACCOUNTS_FROM_GE_EVENTOS_TITLE',
  'id_name' => 'ge_eventos_accountsge_eventos_ida',
);
$dictionary["Account"]["fields"]["ge_eventos_accounts_name"] = array (
  'name' => 'ge_eventos_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_GE_EVENTOS_ACCOUNTS_FROM_GE_EVENTOS_TITLE',
  'save' => true,
  'id_name' => 'ge_eventos_accountsge_eventos_ida',
  'link' => 'ge_eventos_accounts',
  'table' => 'ge_eventos',
  'module' => 'GE_Eventos',
  'rname' => 'name',
);
$dictionary["Account"]["fields"]["ge_eventos_accountsge_eventos_ida"] = array (
  'name' => 'ge_eventos_accountsge_eventos_ida',
  'type' => 'link',
  'relationship' => 'ge_eventos_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_GE_EVENTOS_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
